# AI Auto Article Generator

Plugin WordPress untuk meng-generate artikel secara otomatis menggunakan Anthropic Claude API dan Google Gemini API.

## Fitur Utama
1. **Dynamic Post Type**: Menyimpan hasil generate AI ke sembarang Post Type publik.
2. **Word Count Range**: Atur minimal dan maksimal kata yang diinginkan.
3. **Batch Generation**: Masukkan daftar judul (1 judul per baris), masing-masing akan dibuatkan 1 artikel.
4. **Prompt Templates**: Template mendukung placeholder: `{{title}}`, `{{min_words}}`, `{{max_words}}`, `{{knowledge_base}}`, `{{site_name}}`, `{{current_date}}`.
5. **Knowledge Base**: Tambahkan teks panjang untuk disisipkan ke dalam template.
6. **Auto Schedule**: Posting otomatis (Future) dengan jarak random antar postingan.
7. **Queue System**: Eksekusi melalui WP-Cron di background (1 artikel per eksekusi, jalan setiap 5 menit) agar tidak membebani hosting.
8. **Smart RAG Internal Linking**: Secara otomatis mencari konten relevan yang sudah terbit di situs Anda dan menyisipkannya sebagai internal link natural di dalam artikel baru.
9. **GitHub Auto-Update**: Mendukung pembaruan satu-klik langsung dari dashboard WordPress terintegrasi dengan repositori GitHub Anda.
10. **Logs & Debugging**: Halaman log eksekusi yang rapi dilengkapi pagination dan pembersihan log otomatis (>7 hari) agar database tetap ringan.

## Cara Instalasi
1. Upload folder `indahweb-ai-auto-article` ke dalam `/wp-content/plugins/`.
2. Aktifkan plugin melalui menu **Plugins** di dashboard WordPress.
3. Buka menu **AI Auto Article -> Settings**.
4. Masukkan **API Key** (Anthropic Claude atau Google Gemini) dan klik tombol **Test Connection** untuk menguji.
5. Klik **Save Settings**.

## Cara Penggunaan
1. Buat **Prompt Template** baru di menu *Prompt Template*.
2. (Opsional) Buat **Knowledge Base** jika ingin menyisipkan informasi spesifik.
3. Buka menu **Generate Artikel**.
4. Pilih Post Type, Template, Knowledge Base, rentang kata, status, dan masukkan daftar judul.
5. Klik **Generate ke Antrean**.
6. Buka menu **Daftar Job** untuk melihat status. Job yang berstatus "pending" akan diproses otomatis oleh WP-Cron setiap 5 menit.
7. Anda juga dapat menjalankan eksekusi paksa dengan menekan tombol **Run Now** di halaman *Daftar Job*.
8. Jika ada job yang gagal karena token habis, gunakan tombol **Reset Semua Job Gagal** untuk mengulang antrean.

## Persyaratan
- WordPress 6.0+
- PHP 8.0+

## Riwayat Versi (Changelog)

### v4.4.5
- **Perbaikan Test Connection Anthropic (Error 404 Model)**:
  - Tombol "Test Anthropic Connection" kini menggunakan verifikasi model adaptif multi-tier (`claude-3-haiku-20240307` / `claude-3-5-sonnet-20241022`) sehingga tidak akan lagi gagal 404 pada akun Anthropic standar yang belum mengaktifkan endpoint haiku 3.5.

### v4.4.4
- **Desain Ulang Visual & Tata Letak Modern (Edit & Buat Campaign)**:
  - **Sticky Action Sidebar**: Panel kanan (*Penulis, Jadwal, Tombol Simpan*) kini melayang rapi (*sticky*) mengikuti scroll layar sehingga tidak ada ruang kosong dan tombol simpan selalu mudah dijangkau.
  - **Tombol Variabel Interaktif pada Prompt Utama**: Tag `{{title}}`, `{{min_words}}`, `{{max_words}}`, `{{site_name}}`, `{{current_year}}` pada Prompt Konten Artikel kini bisa diklik langsung (*Click-to-Insert*).
  - **Visual Card Berwarna & Terstruktur**: Pembagian visual yang rapi dengan aksen lembut (Emerald untuk Konten Artikel, Slate untuk Knowledge Base, dan Sky Blue untuk Optimasi SEO).
  - **Header Navigasi Elegan**: Menampilkan nama campaign dengan status badge aktif/jeda serta tombol kembali berikon.

### v4.4.3
- **Penyederhanaan Label Persona & Gaya Sapaan Pembaca**:
  - Mengubah istilah linguistik *"Sudut Pandang (POV)"* menjadi **"Gaya Sapaan Pembaca"** dengan opsi yang jelas: *Menyapa Pembaca ("Anda"/"Kamu")*, *Sudut Pandang Penulis ("Saya"/"Kami")*, dan *Netral & Objektif (Formal/Berita)*.
  - Menambahkan teks petunjuk ringkas di bawah kolom Bahasa, Gaya Penulisan, dan Gaya Sapaan agar lebih ramah bagi pengguna awam.

### v4.4.2
- **Penyempurnaan UX SEO Meta (One-Click Presets & Interactive Chips)**:
  - Tombol **Template Cepat (Quick Presets)** sekali klik untuk Meta Title (*CTR Booster*, *Power Words + Tahun*, *Standar*) dan Meta Description (*Hook + Solusi + CTA*, *Problem + Benefit*).
  - Tag variabel interaktif `{{title}}`, `{{site_name}}`, `{{current_year}}` yang otomatis menyisipkan variabel ke posisi kursor saat diklik (*Click-to-Insert*).
  - Menghilangkan dropdown fallback yang redundan agar antarmuka lebih bersih, fokus, dan tidak membingungkan.

### v4.4.1
- **Pemisahan Jelas & Kustom AI Prompt Khusus SEO**: Pemisahan visual yang jelas antara:
  - **1. AI Prompt Konten Artikel**: Instruksi pembuatan isi artikel, sub-heading, dan pembahasan.
  - **2. AI Prompt Khusus Meta Title**: Textarea instruksi kustom judul SEO (CTR hook, batasan karakter).
  - **3. AI Prompt Khusus Meta Description**: Textarea instruksi kustom deskripsi snippet (CTA, problem/solution).
- **Dukungan Variabel SEO Dinamis**: `{{title}}` (Judul artikel), `{{site_name}}` (Nama website), dan `{{current_year}}` (Tahun berjalan).

### v4.4.0
- **Default Non-Aktif pada Campaign yang Sudah Ada**: Fitur generator SEO Meta Title & Meta Deskripsi diset otomatis ke status **Non-Aktif (OFF)** untuk semua campaign lama yang sedang berjalan agar tidak mengubah konfigurasi yang sudah ada. Pengguna dapat mengaktifkannya kapan saja melalui menu Edit Campaign.
- **Integrasi Multi-Plugin SEO Lengkap**: Kompatibel dengan Rank Math SEO, Yoast SEO, AIOSEO, SEOPress, dan The SEO Framework dengan batas karakter standar mesin pencari (50–60 karakter untuk Meta Title dan 120–155 karakter untuk Meta Description).

### v4.3.9
- **Integrasi Penuh Plugin SEO WordPress**: Kompatibel langsung dengan **Rank Math SEO, Yoast SEO, All in One SEO (AIOSEO), SEOPress,** dan **The SEO Framework**.
- **Generator Meta Title Unik & Panjang Sesuai Rekomendasi Search Engine**: Menghasilkan Meta Title teroptimasi rasio klik (50–60 karakter) agar tidak terpotong di Google SERP dengan berbagai pilihan pola (*AI Dynamic CTR Booster*, *Power Words + Tahun*, *Standar Bersih*).
- **Generator Meta Deskripsi & Focus Keyword**: Menghasilkan deskripsi memikat (120–155 karakter) dan fokus keyword untuk optimasi On-Page SEO otomatis.
- **Kontrol Fleksibel per Campaign**: Fitur SEO dapat diaktifkan atau dinonaktifkan sesuai kebutuhan saat membuat atau mengedit Campaign.

### v4.3.8
- **Pilihan Bahasa & Persona (Tone of Voice & POV)**: Dukungan pilihan bahasa (Indonesia, English, Melayu, dll.), gaya penulisan (Informatif, Kasual/Santai, Profesional, Jurnalistik, Storytelling, Persuasif), dan sudut pandang (POV) per Campaign.
- **Pemilihan Author per Campaign**: Pilih akun penulis/redaktur WordPress yang diinginkan untuk disematkan pada setiap artikel.
- **Filter Status & Tindakan Massal (Bulk Actions)**: Tab filter status (All, Pending, Processing, Completed, Failed, Skipped) serta aksi massal: *Jalankan Terpilih (Bulk Run)*, *Reset Terpilih*, dan *Hapus Terpilih*.
- **Auto-Create Category & Missed Schedule Healing**: Otomatis membuat kategori baru jika belum ada di WordPress dan auto-publish artikel terjadwal yang terlewat.

### v4.3.7
- **Perbaikan Sinkronisasi Waktu (Timezone Fix)**: Memperbaiki inkonsistensi perbandingan waktu lokal vs UTC pada auto-recovery job macet di background cron.
- **Pencatatan Model AI Akurat**: Menyimpan model AI yang sebenarnya digunakan ke dalam meta post (`_ai_article_model`).
- **Optimasi Test Connection AI**: Uji koneksi API Anthropic, OpenAI, dan Google Gemini berlangsung instan (< 1 detik) tanpa timeout berlebih.
- **Paginasi Antrean Job**: Navigasi halaman (pagination 50 per halaman) pada Daftar Job untuk mempermudah pemantauan ratusan/ribuan antrean artikel.
- **Hardening Keamanan & Cleanup**: Penambahan verifikasi hak akses `manage_options` di setiap aksi admin dan penyempurnaan pembersihan seluruh tabel/opsi saat uninstall.

### v4.3.6
- **Pencegahan Judul Duplikat**: Otomatis mengecek apakah judul artikel sudah terdaftar di WordPress (pada *post type* target). Jika sudah ada, sistem akan melompati (*skip*) job tersebut dan mengubah statusnya menjadi **`SKIPPED`** dengan detail label warna jingga agar terhindar dari *duplicate content*.

### v4.3.5
- **Optimasi Performa & Keamanan Antrean**: Ditambahkan batas waktu eksekusi dinamis (`set_time_limit`) dan sistem penguncian baris DB atomik untuk menghindari *race conditions* dan duplikasi pembuatan artikel.

### v4.3.4
- **Tombol Reset Antrean Gagal**: Ditambahkan tombol *"Reset Semua Job Gagal"* di halaman antrean untuk memulihkan status job yang gagal & mengulangi antrean pasca pengisian token API.

### v4.3.3
- **Pembaruan Kepemilikan & Profil**: Mengubah nama pembuat (*Author*) menjadi *Mujaddid Halimurrosyid* dan tautan ke *Indahweb.com*.

### v4.3.2
- **Integrasi GitHub Auto-Update**: Penambahan fitur cek versi dan instalasi pembaruan otomatis satu-klik langsung dari dashboard WordPress.

### v4.3.1
- **Batasan Internal Link**: Penambahan opsi kustomisasi jumlah maksimal rekomendasi tautan internal (*Smart RAG*) pada halaman Settings untuk menghindari kepadatan link.

### v4.3.0
- **Perbaikan Alur Redirect**: Mengubah alur submit form pembuatan artikel agar mengarah kembali ke Daftar Campaign secara stabil tanpa layar kosong/blank.

### v4.2.8
- **Pembersihan Log Aman (Shared Hosting)**: Mengubah perintah `TRUNCATE` menjadi `DELETE FROM` untuk mendukung hosting tanpa hak akses drop table.
- **Auto-Cleanup Log**: Log berumur > 7 hari otomatis dibersihkan di latar belakang.
- **Pagination & UI List**: Navigasi halaman untuk log eksekusi (20 baris per halaman) dan perbaikan tombol aksi bertumpuk pada tabel antrean.
